---
name: git-github-windows-china
description: 本机（Windows git-bash + 中国网络）的 Git/GitHub 操作流程：VPN/代理探测、镜像加速回退、git.exe 路径解析坑。凡是 clone/pull/push GitHub 仓库都先按此流程走。
category: software-development
trigger_keywords:
  - git clone
  - 拉取仓库
  - 把项目拉下来
  - git push
  - GitHub 下载
---

# Git/GitHub on Windows + 中国网络

本机环境：git-bash (MSYS)，Clash 代理（Mihomo 内核）`http.proxy=127.0.0.1:7897`。VPN 不开时端口不可达，直接 clone 报 `Failed to connect to 127.0.0.1 port 7897`。

## 标准流程

### 1. 先探测代理端口（1 秒确认，别盲试 clone）
```bash
timeout 3 bash -c 'echo > /dev/tcp/127.0.0.1/7897' 2>/dev/null && echo "PROXY OK" || echo "PROXY DOWN"
```

### 2a. PROXY OK → 正常走代理
```bash
git clone https://github.com/<owner>/<repo>.git "E:/target-dir"
```

### 2b. PROXY DOWN → 镜像加速 + 临时绕过代理配置
不要让用户先开 VPN 再等——镜像直连通常更快：
```bash
git clone -c http.proxy= -c https.proxy= --depth 1 \
  https://ghfast.top/https://github.com/<owner>/<repo>.git "E:/target-dir"
```
- `-c http.proxy= -c https.proxy=` 必须加，否则仍会撞全局代理配置
- 镜像备选（ghfast.top 挂了依次换）：`gh-proxy.com`、`ghproxy.net`
- 镜像只适合 clone/pull 公开仓库；**push / 私有仓库必须开 VPN 走代理**（memory 已有此规则）

## ⚠️ 致命坑：git.exe 不认 MSYS 路径

**目标路径写 `/e/xxx` 时，原生 git.exe 会把它解析成"当前盘符根目录"下的 `\e\xxx`**（如 cwd 在 C 盘 → 实际克隆到 `C:\e\xxx`），且输出仍显示 `Cloning into '/e/xxx'`、正常报 100% done，**完全无报错、极具迷惑性**。

规则：
1. git 命令的路径参数一律写 Windows 风格：`E:/grok-build` 或 `E:\\grok-build`，不要写 `/e/grok-build`
2. clone 完必须验证落点：`ls "E:/target-dir"` — 找不到就去 `C:\e\`、`C:\Program Files\Git\` 下找丢失的目录，用 `mv` 搬回
3. bash 内建命令（ls/mv/mkdir）认 `/e/` 没问题——**只有原生 .exe（git、python 等）会踩这个坑**

## Hermes 工具路径同坑

`read_file` / `search_files` / `write_file` 等 Hermes 文件工具**只认 Windows 路径** `E:\dir\file`，传 `/e/dir/file` 会报 "Path not found"。terminal 里的 bash 命令则两种都认。

## ⚠️ 致命坑 2：后台 git clone 僵死（Agent 场景）

Hermes Agent 用 `terminal(background=true)` 或通过 `delegate_task` 跑的 git clone，会出现 **`.git/` 创建但文件未 checkout** 的僵尸状态：

**症状：**
- 目录下只有 `.git/`，无实际文件（`ls` 返回空）
- `.git/objects/pack/tmp_pack_*` 和 `.git/shallow.lock` 锁住目录
- `rm -rf` 报 `Device or resource busy`
- `ps aux | grep git` 能看到残留进程（PPID 被重定向到 1）

**根因：** 后台 clone 的 fetch/checkout 阶段超时，或被 Agent 会话提前断开。git-bash 的 `kill -9` 对 Windows 原生 git.exe 无效。

**修复流程：**

```bash
# 1. 查看僵尸进程
ps aux | grep git

# 2. 用 Windows taskkill 杀（非 git-bash 的 kill）
/c/Windows/System32/taskkill.exe /F /IM git.exe

# 3. 等锁释放
sleep 3

# 4. 用新目录名重新克隆（避免旧锁残留）
git clone --depth 1 --single-branch <url> "<path>_new"

# 5. 成功后重命名
mv "<path>_new" "<path>"
```

**预防：** 大仓库（≥100MB）用 `notify_on_complete=true` + `timeout=300`，不无超时裸跑。`--single-branch` 可减少 fetch 带宽，降低 RPC 断流风险。

### 大仓库 RPC 断流

SillyTavern 等级别的大仓 clone 中途可能报：
```
error: RPC failed; curl 92 HTTP/2 stream 5 was not closed cleanly: CANCEL (err 8)
```
**对策（🆕 2026-07-20 实战验证）：**
```bash
# 1. 增大缓冲区
git config --global http.postBuffer 524288000  # 500MB

# 2. 强制 HTTP/1.1（Clash 对 HTTP/2 分流差，大文件必断）
git config --global http.version HTTP/1.1

# 3. 用 --single-branch 减少 fetch 开销
git clone --depth 1 --single-branch <url> <path>
```

**大仓库单线程策略：** 不要并行克隆多个大仓库通过同一代理（SillyTavern + Soul-of-Waifu 同时 clone → 打满代理带宽 → 全部超时）。逐一排队克隆。小仓库（Memobase ~368 文件）可以并行。

## 验证清单
- [ ] clone 后 `ls` 确认目标目录非空 + 有实际文件（不只是 `.git/`）
- [ ] `du -sh` 看体积是否合理（怀疑浅克隆丢文件时）
- [ ] 后续要给 Hermes 文件工具用的路径，统一转成 `E:\...` 格式

## 代理端口历史
- 2026.7 前：10808（V2Ray/其他工具）
- 2026.7 起：7897（Clash Verge v2.4.7，Mihomo v1.19.21 内核，混合端口）
- 如 Clash 版本更新可能再次换端口——push 失败时先用 `netstat -ano | grep LISTEN` 查当前端口
