---
name: windows-gitbash-quirks
description: Windows git-bash/MSYS 环境下的路径转换陷阱与 GitHub 网络访问模式。git clone 目标盘符跑偏、Hermes 文件工具/原生 python 的路径格式要求、代理端口探测与镜像加速降级。任何在此机器上 clone 仓库、跨盘操作文件、或 GitHub 访问失败时加载。
---

# Windows git-bash 路径与网络陷阱

## 触发条件
在这台 Windows 机器 (git-bash/MSYS shell) 上: git clone/push、跨盘符文件操作、调用 python 脚本、GitHub 访问失败/代理问题。

## 一、路径转换陷阱（都是实际踩过的）

### 1. git clone 目标路径跑偏 ⚠️ 最阴险
`git clone <url> /e/foo` 会打印 `Cloning into '/e/foo'` 并"成功"，但原生 git.exe 实际把 `/e/foo` 解析成**当前盘符根下的 \e\foo**（cwd 在 C: 时 → `C:\e\foo`）。输出完全看不出问题。

- **规则**: clone/checkout 目标一律用 Windows 正斜杠格式 `E:/foo`，或先 `cd /e` 再用相对路径。
- **必须验证**: clone 完立刻 `ls <目标>` 确认文件真的在。不在时查 `C:\e\`、`C:\Program Files\Git\<路径>`。
- 搬运补救: `mv /c/e/foo /e/foo && rmdir /c/e`（bash 的 mv 是 MSYS 程序, 正确理解 /e/ 挂载）。

### 2. Hermes 文件工具不认 MSYS 路径
`read_file`/`search_files` 传 `/e/foo` 报 "Path not found"。**必须用 `E:\foo` 或 `E:/foo`**。terminal 里的 bash 命令 (ls/mv/grep) 则两种都认。

### 3. 原生 python 不认 /c/ 路径
本机 python 是 anaconda 原生 exe: `python /c/Users/x/script.py` 报 "can't open file 'C:\\c\\Users\\...'"（MSYS 参数转换没生效时直接拼盘符）。**传脚本路径用 `C:/Users/x/script.py`**。

### 4. npm config prefix 跑偏 ⚠️
`npm config set prefix /e/npm-global` → npm 解析为 `C:\e\npm-global`（当前盘符根下），而不是 E 盘。
- **规则**: npm config 传路径一律用 Windows 格式 `"E:\\npm-global"`，不用 MSYS `/e/...`。
- **验证**: `npm config get prefix` 确认输出是 `E:\\npm-global` 而非 `C:\\e\\npm-global`。
- **清理**: 跑偏后 `rm -rf "C:/e/npm-global"` + 修正 prefix + 重装。

### 5. 通用规则
正斜杠 Windows 路径 `C:/Users/...` 在 bash、python、git、Hermes 工具里全部通用 — 拿不准就用它。
- 扩展: 不仅仅是 Hermes 文件工具和 git，**npm/yarn/pnpm 等 Node 生态工具的 config 路径也受此影响**，传路径前先想清楚用的是 MSYS 感知程序还是原生 Win32 程序。

## 二、GitHub 访问决策链

```
1. 探测代理:  timeout 3 bash -c 'echo > /dev/tcp/127.0.0.1/<端口>' && echo OK || echo DOWN
   本机端口: 10808 = V2Ray(git 全局配置写的是它); 7897 = Clash Verge 混合端口(用户常开的是这个)
   ⚠️ 两者不一定同时在跑 — git config 里的代理端口 ≠ 用户当前实际开的代理
2. 代理通    → 直接 git clone/push
3. 代理不通  → 镜像加速 + 临时绕过 git 全局代理配置:
   git clone -c http.proxy= -c https.proxy= --depth 1 \
     https://ghfast.top/https://github.com/<owner>/<repo>.git E:/<dest>
   (ghfast.top 前缀加速, 实测满速; 失效备选: gh-proxy.com, ghproxy.net)
4. 镜像只解决 clone/pull; push 回 GitHub 仍需真代理/VPN
```

- `-c http.proxy= -c https.proxy=` 是**单次命令级**覆盖, 不污染全局配置, 优于改 `git config --global`。
- GitHub API 搜索 (api.github.com) 国内常可直连, 找仓库全名可以先 `curl -s "https://api.github.com/search/repositories?q=..."` 不需要代理。

## 三、验证清单
- clone 后: `ls <目标目录>` + `du -sh` 确认非空
- 改代理后: 先 /dev/tcp 探测端口再跑 git, 别用 git 报错当探测器 (报错慢且信息混淆)
